function  RMSE= calMSE(GrtR, GrtT, pM, data, s)


N= length(pM);
Model= [];
Data= [];
pM0(1:4,1:3) = [GrtR{1,1};0 0 0];
pM0(1:4,4) = [GrtT{1,1}*s;1];
pMM0= pM(1).M;
for i=1:N
    p(i).M(1:4,1:3) = [GrtR{1,i};0 0 0];
    p(i).M(1:4,4) = [GrtT{1,i}*s;1];
    p(i).M= inv(pM0)* p(i).M;
    TData= transform_to_global(data{i}', p(i).M(1:3,1:3),p(i).M(1:3,4));
    Data= [Data, TData];
    
    pM(i).M= inv(pMM0)* pM(i).M;
    TModel= transform_to_global(data{i}', pM(i).M(1:3,1:3),pM(i).M(1:3,4));
    Model= [Model, TModel];   
end
% plot3(Model(1,:),Model(2,:),Model(3,:),'.');
Num= size(Data,2);
RMSE= sqrt(sum(sum((Model-Data).^2)')/Num);