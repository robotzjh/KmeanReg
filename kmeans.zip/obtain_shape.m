function [Pnum,Model]= obtain_shape(dataN,pM,N)

Pnum= [];
Model= [];
for i=1:N
    Data= dataN{i,1}';
    R0= pM(i).M(1:3,1:3);    t0= pM(i).M(1:3,4);
    num= size(Data,2);
    Pnum= [Pnum,num];
    TData= transform_to_global(Data, R0, t0);
    Model= [Model,TData];
end


