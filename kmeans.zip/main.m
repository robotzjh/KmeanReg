clc
clear all
close all
load Bunny
scannum= size(data,2);
res= 8;
s= 1000;
for i=1:scannum
    scan= data{1,i}';
    shape{i,1}= scan;
    shape1{i,1}= scan(1:res:end,:)*s;
    MSEs= cal_mMSEs(shape1{i,1}');
    t0 = MSEs*(2*rand(3,1)-1)*2;                    % Turbulence of t
    Noi_GrtT{i} = GrtT{i}*s + t0;
    theta= (2*pi*rand(3,1)-pi)*0.01;              % Turbulence of R
    M(1:3,1:3)= OulerToRota(theta);
    Noi_GrtR{i} = M*GrtR{i};
    p(i).M(1:4,1:3) = [Noi_GrtR{i};0 0 0];
    p(i).M(1:4,4) = [Noi_GrtT{i};1];
end
p(1).M = eye(4);


%%   Initial Value
[errR0,errT0]= err_comp(GrtR, GrtT, p, scannum, s)
Model=obtain_model(shape, p, scannum, s);
crosssection(Model,1,-20.1,-19.8); % bunny

%%   Kmeans method
Nmu= 25; 
tic
[pM1, Model]= KmeansReg(p, shape1, scannum, Nmu, 500);
T1 = toc
[errR1,errT1]= err_comp(GrtR, GrtT, pM1, scannum, s)
figure
Model=obtain_model(shape, pM1, scannum, s);
crosssection(Model,1,-20.1,-19.8); % bunny








