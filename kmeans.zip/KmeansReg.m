function [pM, Model]= KmeansReg(pM, shape, N, Nmu, Nit)

[Pnum, Model]= obtain_shape(shape,pM,N);
mu= Model(:,1:Nmu:end);                      % Initialize cluster centroids
Nmu= size(mu,2);
err= 10;
it= 0;
ERROR= (N-1)*10^(-6);
PN= sum(Pnum);
while ((it<Nit)&(err>ERROR))
    it= it+1;
    % Data assigment step
    NS = createns(mu');
    [corr,TD] = knnsearch(NS,Model');
    % Centroid update step
    muN= zeros(1,Nmu);
    mu= zeros(3,Nmu);
    
% Pay more attention to the 1st scan
    for i=1:Pnum(1)
        mu(:,corr(i))=mu(:,corr(i))+Model(:,i)*5*N;
        muN(1,corr(i))= muN(1,corr(i))+5*N;
    end
    for i= (Pnum(1)+1):PN
        mu(:,corr(i))=mu(:,corr(i))+Model(:,i);
        muN(1,corr(i))= muN(1,corr(i))+1;
    end 
   
%     % Regular way
%     for i= 1:length(corr)
%         mu(:,corr(i))=mu(:,corr(i))+Model(:,i);
%         muN(1,corr(i))= muN(1,corr(i))+1;
%     end
 
    muN= repmat(muN,3,1);
    mu= mu./muN;
    %     
    % Multi-view registration step
    err= 0;
    sigma= mean(TD);
    for i= 2:N
        [id1,id2]= gen_ID(Pnum,i);
        Data= Model(:,id1:id2);
        Model(:,id1:id2)= [];
        corri= corr(id1:id2);
        corri(:,2) = [1 : length(corri)]';
        [M, TData] = reg(corri,mu,Data);
        pM= recover(pM,M,i);
        Model= assemble(id1,Model,TData);
        err= sum(sum(abs(M(1:3,1:3)-eye(3)))')+err;
    end
end

% plot3(mu(1,:),mu(2,:),mu(3,:),'.r');

function [M, TData] = reg(corr, Model, Data)
n = length(corr); 
M = Model(:,corr(:,1)); 
mm = mean(M,2);
S = Data(:,corr(:,2));
ms = mean(S,2); 
Sshifted = [S(1,:)-ms(1); S(2,:)-ms(2); S(3,:)-ms(3)];
Mshifted = [M(1,:)-mm(1); M(2,:)-mm(2); M(3,:)-mm(3)];
K = Sshifted*Mshifted';
K = K/n;
[U A V] = svd(K);
R1 = V*U';
if det(R1)<0
    B = eye(3);
    B(3,3) = det(V*U');
    R1 = V*B*U';
end
t1 = mm - R1*ms;
M= Rt2M(R1,t1);  
TData = transform_to_global(Data, R1, t1);


